require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

const storage = multer.memoryStorage();
const uploader = multer({ storage });

app.use(cors());
app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', (req, res) => {
  res.sendFile(process.cwd() + '/views/index.html');
});

app.post('/api/fileanalyse', uploader.single('upfile'), (req, res) => {
  if (!req.file) return res.json({ error: 'no file uploaded' });

  res.json({
    name: req.file.originalname,
    type: req.file.mimetype,
    size: req.file.size
  });
});

app.listen(PORT, () => {
  console.log(`Louisse Ken File Metadata Service running on port ${PORT}`);
});